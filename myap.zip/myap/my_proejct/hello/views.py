from urllib import request
from django.shortcuts import render,redirect
from  hello.models  import ContactForm,contactEnquiry
from  hello.forms import FormContactForm
from .forms import NewUserForm

from django.http import HttpResponse
from django.contrib.auth import login, authenticate #add this
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.db.models  import Q


def index(request):
    
    data="50"
    
    request.session['paid']=data
 

    return render(request, "home.html",{'data':data})

def home(request): 
    data='5000'
    
    
    print(request.session['paid']) 
    return render(request, "home.html",{'data':data})

def about(request):

    data=request.session.get('paid')

    return render(request, "about.html",{'data':data})






def showform(request):
    form= FormContactForm(request.POST or None)
    if form.is_valid():
        form.save()
  
    context= {'form': form }
        
    return render(request, 'contactform.html', context)


def saveenquiry(request):

 

 if request.method=="POST":
        
  email=request.POST['email']
  name=request.POST['name']

  

 message=request.POST['msg']

 en=contactEnquiry(name=name,email=email,message=message)

 en.save()

 n='data inserted'

 return render(request,"contact.html",{'n':n})



def home(request):
 serviceData=ContactForm.objects.all()
 data={'serviceData':serviceData
        }


 return render(request,"home.html",data)

def  editemp(request,id):
 data=ContactForm.objects.get(id=id)
 return render(request, "edit.html",{'editupdaterecord':data})


def  updateemp(request,id):
 if request.method=='POST':
  pi=ContactForm.objects.get(id=id)
  form= FormContactForm(request.POST ,instance=pi)
 if form.is_valid():
        
        form.save()
 msg="record updated"
 return render(request, "update.html",{'editupdaterecord':msg})
      

def search(request):
    if request.GET.get('myform'): # write your form name here      
        book_name =  request.GET.get('myform')  
           
        try:
                
            status = ContactForm.objects.filter(fullname__icontains=book_name)
            return render(request,"search1.html",{"books":status})
        except:
            return render(request,"search1.html",{'books':status})
    else:
        return render(request, 'search1.html', {'books':status})


def search1(request):
 if 'q'  in request.GET:
    q=request.GET['q']
    multiple_q=Q(Q(fullname=q)| Q(message=q))
    data=ContactForm.objects.filter(multiple_q)
    
 else:
    data =ContactForm.objects.all()
    
 return render(request,'search1.html',{
 'data':data
 })

 

def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"You are now logged in as {username}.")
				return redirect("home")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request, 'login.html', context={"login_form":form})

def register_request(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return redirect("home")
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render (request, 'register.html', context={"register_form":form})