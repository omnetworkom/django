from django.contrib import admin
from .models import contactEnquiry,ContactForm

# Register your models here.

admin.site.register(contactEnquiry)
admin.site.register(ContactForm)



list_display = ['fullname', 'email','contact','message' ]