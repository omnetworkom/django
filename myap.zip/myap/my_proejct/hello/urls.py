from django.urls import path

from .import views



urlpatterns=[
path('',views.index,name='index'),
path('home/',views.home,name='home'),
path('about/',views.about,name='about'),

path('showform/', views.showform),
path('search/', views.search,name='search'),
path('search1/', views.search1,name='search1'),


path('editemp/<int:id>', views.editemp, name='editemp'),
path('updateemp/<str:id>', views.updateemp, name='updateemp'),

path('saveenquiry/',views.saveenquiry,name="saveenquiry"),
     path("register", views.register_request, name="register"),
         path("login", views.login_request, name="login")









]
