from django.db import models

# Create your models here.

class ContactForm(models.Model):
        

    fullname= models.CharField(max_length=100)
    email= models.EmailField()
    contact= models.CharField(max_length=50)
    message= models.CharField(max_length=200)
    
class contactEnquiry(models.Model):

 name=models.CharField(max_length = 50)

 email=models.CharField(max_length = 50)

 message=models.TextField(max_length=50)

 class Dreamreal(models.Model):

   website = models.CharField(max_length = 50)
   mail = models.CharField(max_length = 50)
   name = models.CharField(max_length = 50)
   phonenumber = models.IntegerField()

   class Meta:
      db_table = "dreamreal"


class editupdaterecord(models.Model):

 empname=models.CharField(max_length=50)

email=models.CharField(max_length=50)

salary=models.IntegerField()

class Meta:

    db_table="empdetails"

    